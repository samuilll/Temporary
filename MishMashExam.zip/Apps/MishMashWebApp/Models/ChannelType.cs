﻿namespace MishMashWebApp.Models
{
    public enum ChannelType
    {
        Game = 1,
        Motivation = 2,
        Lessons = 3,
        Radio = 4,
        Other = 5,
    }
}