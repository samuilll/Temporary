﻿using System;

namespace SIS.MvcFramework
{
    public class AuthorizeAttribute : Attribute
    {
    }
}
